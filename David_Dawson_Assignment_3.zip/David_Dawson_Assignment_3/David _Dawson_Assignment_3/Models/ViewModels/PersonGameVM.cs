﻿using David__Dawson_Assignment_3.Models.Entities;

namespace David__Dawson_Assignment_3.Models.ViewModels
{
    public class PersonGameVM
    {
        public Person? Person { get; set; }
        public Game? Game { get; set; }
    }
}
