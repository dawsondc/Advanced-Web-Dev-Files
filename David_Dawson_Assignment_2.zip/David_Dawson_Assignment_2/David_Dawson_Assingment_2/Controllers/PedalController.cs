﻿using David_Dawson_Assingment_2.Models.Entities;
using David_Dawson_Assingment_2.Services;
using Microsoft.AspNetCore.Mvc;

namespace David_Dawson_Assingment_2.Controllers
{
    public class PedalController : Controller
    {
        /// <summary>
        /// Readonly for the Repo
        /// </summary>
        private readonly IPedalRepository _pedalRepo;

        /// <summary>
        /// controller instance
        /// </summary>
        /// <param name="pedalRepo"></param>
        public PedalController(IPedalRepository pedalRepo)
        {
            _pedalRepo = pedalRepo;
        }


        /// <summary>
        /// action to display the list
        /// </summary>
        /// <returns> readall view </returns>
        public IActionResult Index()
        {
            var model = _pedalRepo.ReadAll();
            return View(model);
        }

        /// <summary>
        /// Get for Create
        /// </summary>
        /// <returns> The create View </returns>
        public IActionResult Create()
        {
            return View();
        }

        /// <summary>
        /// Post for the create view
        /// </summary>
        /// <param name="Pedal"></param>
        /// <returns> returns back to index if entry is valid. IF not valid, return to index </returns>
        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult Create(Pedals Pedal)
        {
            //IF entry details are valid, add entry to database and return to index
            if (ModelState.IsValid)
            {
                _pedalRepo.Create(Pedal);
                return RedirectToAction("Index");
            }
            return View(Pedal);
        }

        /// <summary>
        /// Get for the Details View
        /// </summary>
        /// <param name="ID"></param>
        /// <returns> The Details View </returns>
        public IActionResult Details(int ID)
        {
            var details = _pedalRepo.Read(ID);

            //IF entry is null, return to index (do nothing basically)
            if (details == null)
            {
                return RedirectToAction("Index");
            }
            return View(details);
        }

        /// <summary>
        /// GET for the UPDATE view
        /// </summary>
        /// <param name="ID"></param>
        /// <returns> if update isnt NULL, retrurns updated entry </returns>
        public IActionResult Edit(int ID)
        {
            var update = _pedalRepo.Read(ID);

            //IF edit is null (not changed) return to index
            if (update == null)
            {
                return RedirectToAction("Index");
            }

            return View(update);
        }

        /// <summary>
        /// POST for the UPDATE view
        /// </summary>
        /// <param name="pedal"></param>
        /// <returns> updated entries </returns>
        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult Edit(Pedals pedal)
        {
            if (ModelState.IsValid)
            {
                _pedalRepo.Update(pedal.ID, pedal);
                return RedirectToAction("Index");
            }
            return View(pedal);
        }

        /// <summary>
        /// GET for DELETE view
        /// </summary>
        /// <param name="ID"></param>
        /// <returns> DELETE view</returns>
        public IActionResult Delete(int ID)
        {
            var delete = _pedalRepo.Read(ID);

            if (delete == null)
            {
                return RedirectToAction("Index");
            }
            return View(delete);
        }

        /// <summary>
        /// POST for the delete view
        /// </summary>
        /// <param name="ID"></param>
        /// <returns> Confirms delete then returns to the list </returns>
        [HttpPost, ValidateAntiForgeryToken, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int ID)
        {
            _pedalRepo.Delete(ID);
            return RedirectToAction("Index");
        }

    }
}
