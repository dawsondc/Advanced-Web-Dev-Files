﻿using David_Dawson_Assingment_2.Models.Entities;
using David_Dawson_Assingment_2.Services;
using Microsoft.AspNetCore.Mvc;

namespace David_Dawson_Assingment_2.Migrations
{
    public class GuitarController : Controller
    {
        /// <summary>
        /// Readonly for the Repo
        /// </summary>
        private readonly IGuitarRepository _guitarRepo;

        /// <summary>
        /// controller instance
        /// </summary>
        /// <param name="guitarRepo"></param>
        public GuitarController(IGuitarRepository guitarRepo)
        {
            _guitarRepo = guitarRepo;
        }

        /// <summary>
        /// action to display the list
        /// </summary>
        /// <returns> readall view</returns>
        public IActionResult Index()
        {
            var model = _guitarRepo.ReadAll();
            return View(model);
        }

        /// <summary>
        /// Get for Create
        /// </summary>
        /// <returns> The create View </returns>
        public IActionResult Create()
        {
            return View();
        }

        /// <summary>
        /// Post for the create view
        /// </summary>
        /// <param name="Guitar"></param>
        /// <returns> returns back to index if entry is valid. IF not valid, return to index </returns>
        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult Create(GuitarDetails Guitar)
        {
            //IF entry details are valid, add entry to database and return to index
            if (ModelState.IsValid)
            {
                _guitarRepo.Create(Guitar);
                return RedirectToAction("Index");
            }
            return View(Guitar);
        }

        /// <summary>
        /// Get for the Details View
        /// </summary>
        /// <param name="ID"></param>
        /// <returns> The Details View </returns>
        public IActionResult Details(int ID)
        {
            var details = _guitarRepo.Read(ID);

            //IF entry is null, return to index (do nothing basically)
            if (details == null)
            {
                return RedirectToAction("Index");
            }
            return View(details);
        }

        /// <summary>
        /// GET for the UPDATE view
        /// </summary>
        /// <param name="ID"></param>
        /// <returns> if update isnt NULL, retrurns updated entry </returns>
        public IActionResult Edit(int ID)
        {
            var update = _guitarRepo.Read(ID);

            //IF edit is null (not changed) return to index
            if (update == null)
            {
                return RedirectToAction("Index");
            }

            return View(update);
        }

        /// <summary>
        /// POST for the UPDATE view
        /// </summary>
        /// <param name="guitar"></param>
        /// <returns> updated entries </returns>
        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult Edit(GuitarDetails guitar)
        {
            if (ModelState.IsValid)
            {
                _guitarRepo.Update(guitar.ID, guitar);
                return RedirectToAction("Index");
            }
            return View(guitar);
        }

        /// <summary>
        /// GET for DELETE view
        /// </summary>
        /// <param name="ID"></param>
        /// <returns> DELETE view</returns>
        public IActionResult Delete(int ID)
        {
            var delete = _guitarRepo.Read(ID);

            if (delete == null)
            {
                return RedirectToAction("Index");
            }
            return View(delete);
        }

        /// <summary>
        /// POST for the delete view
        /// </summary>
        /// <param name="ID"></param>
        /// <returns> Confirms delete then returns to the list </returns>
        [HttpPost, ValidateAntiForgeryToken, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int ID)
        {
            _guitarRepo.Delete(ID);
            return RedirectToAction("Index");
        }

    }
}
