﻿using David_Dawson_Assingment_2.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace David_Dawson_Assingment_2.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// Redirecting to the guitar index page
        /// </summary>
        /// <returns> Guitar index view </returns>
        public IActionResult Index()
        {
            return View();
            //return RedirectToAction("Index", "Guitar");
            //return RedirectToAction("Index", "Pedal");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}