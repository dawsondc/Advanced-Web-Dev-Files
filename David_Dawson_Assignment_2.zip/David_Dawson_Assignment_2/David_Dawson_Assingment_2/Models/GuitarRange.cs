﻿namespace David_Dawson_Assingment_2.Models
{
    /// <summary>
    /// enum of a guitars price/player range
    /// </summary>
    public enum GuitarRange
    {
        Entry,
        Intermediate,
        Expert

    }
}
