﻿namespace David_Dawson_Assingment_2.Models.Entities
{
    /// <summary>
    /// class of propoerties for getting the guitar specs
    /// </summary>
    public class GuitarDetails
    {
        public int ID { get; set; }
        public string Brand { get; set; }
        public string Model { get; set; }
        public string Color { get; set; }
        public string Hardware { get; set; }
        public string Pickups { get; set; }
        public GuitarRange Range { get; set; }
        public int releaseYear { get; set; }

        
    }
}
