﻿namespace David_Dawson_Assingment_2.Models.Entities
{
    /// <summary>
    /// Class of Get Set properties for the table of pedals
    /// </summary>
    public class Pedals
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Brand { get; set; }
        public string Effect { get; set; }
    }
}
