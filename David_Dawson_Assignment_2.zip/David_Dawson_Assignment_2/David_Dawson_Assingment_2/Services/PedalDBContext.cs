﻿using David_Dawson_Assingment_2.Models.Entities;
using Microsoft.EntityFrameworkCore;

namespace David_Dawson_Assingment_2.Services
{
    /// <summary>
    /// Linking context to database through the connection string
    /// </summary>
    public class PedalDBContext : DbContext
    {
        public PedalDBContext(DbContextOptions options) : base(options)
        {

        }
        /// <summary>
        /// Setting Table
        /// </summary>
        public DbSet<Pedals> Pedals { get; set; }
    }
}
