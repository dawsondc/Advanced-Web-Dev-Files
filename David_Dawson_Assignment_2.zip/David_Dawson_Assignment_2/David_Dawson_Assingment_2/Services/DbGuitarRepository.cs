﻿using David_Dawson_Assingment_2.Models.Entities;

namespace David_Dawson_Assingment_2.Services
{
    /// <summary>
    /// Class to talk to database
    /// </summary>
    public class DbGuitarRepository : IGuitarRepository
    {
        /// <summary>
        /// Implementing ReadAll Method
        /// </summary>
        /// <returns> List of entries </returns>
        public ICollection<GuitarDetails> ReadAll()
        {
            return _db.Guitars.ToList();
        }

        
        private GuitarDBContext _db;
        /// <summary>
        /// instance of the repo and giving it the DB Context
        /// </summary>
        /// <param name="db"></param>
        public DbGuitarRepository(GuitarDBContext db)
        {
            _db = db;
        }

        /// <summary>
        /// Implementing Create Method
        /// </summary>
        /// <param name="Guitar"></param>
        /// <returns> Saves any new entries and returns it to view </returns>
        public GuitarDetails Create(GuitarDetails Guitar)
        {
            _db.Guitars.Add(Guitar);
            _db.SaveChanges();
            return Guitar;
        }

        /// <summary>
        /// Implementing the read method
        /// </summary>
        /// <param name="ID"></param>
        /// <returns> atrributes of the entity </returns>
        public GuitarDetails? Read(int ID)
        {
            return _db.Guitars.Find(ID);
        }

        /// <summary>
        /// Implementing Update Method
        /// </summary>
        /// <param name="oldID"></param>
        /// <param name="guitar"></param>
        public void Update(int oldID, GuitarDetails guitar)
        {
            
            GuitarDetails? guitarToUpdate = Read(oldID);

            if (guitarToUpdate != null)
            {
                guitarToUpdate.Brand = guitar.Brand;
                guitarToUpdate.Model = guitar.Model;
                guitarToUpdate.Color = guitar.Color;
                guitarToUpdate.Hardware = guitar.Hardware;
                guitarToUpdate.Pickups = guitar.Pickups;
                guitarToUpdate.Range = guitar.Range;
                guitarToUpdate.releaseYear = guitar.releaseYear;

                _db.SaveChanges();
            }
        }
        
        /// <summary>
        /// Implementing Delete Method
        /// </summary>
        /// <param name="ID"></param>
        public void Delete(int ID)
        {
            GuitarDetails? guitarToDelete = Read(ID);

            if (guitarToDelete != null)
            {
                _db.Remove(guitarToDelete);
                _db.SaveChanges();
            }
        }
    }
}
