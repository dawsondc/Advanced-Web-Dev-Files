﻿using David_Dawson_Assingment_2.Models.Entities;
using Microsoft.EntityFrameworkCore;

namespace David_Dawson_Assingment_2.Services
{
    /// <summary>
    /// Linking context to database through the connection string
    /// </summary>
    public class GuitarDBContext : DbContext
    {
        public GuitarDBContext(DbContextOptions <GuitarDBContext> options) : base(options)
        {

        }
        /// <summary>
        /// Setting Table
        /// </summary>
        public DbSet<GuitarDetails> Guitars { get; set; } 
    }
}
