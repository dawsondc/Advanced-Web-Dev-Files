﻿using David_Dawson_Assingment_2.Models.Entities;

namespace David_Dawson_Assingment_2.Services
{
    public class DbPedalRepository : IPedalRepository
    {

        private PedalDBContext _db;
        /// <summary>
        /// instance of the repo and giving it the DB Context
        /// </summary>
        /// <param name="db"></param>
        public DbPedalRepository(PedalDBContext db)
        {
            _db = db;
        }

        /// <summary>
        /// Implementing ReadAll Method
        /// </summary>
        /// <returns> List of entries </returns>
        public ICollection<Pedals> ReadAll()
        {
            return _db.Pedals.ToList();
        }

        /// <summary>
        /// Implementing Create Method
        /// </summary>
        /// <param name="Pedal"></param>
        /// <returns> Saves any new entries and returns it to view </returns>
        public Pedals Create(Pedals Pedal)
        {
            _db.Pedals.Add(Pedal);
            _db.SaveChanges();
            return Pedal;
        }

        /// <summary>
        /// Implementing the read method
        /// </summary>
        /// <param name="ID"></param>
        /// <returns> atrributes of the entity </returns>
        public Pedals Read(int ID)
        {
            return _db.Pedals.Find(ID);
        }

        /// <summary>
        /// Implementing Update Method
        /// </summary>
        /// <param name="oldID"></param>
        /// <param name="pedal"></param>
        public void Update(int oldID, Pedals pedal)
        {

            Pedals? pedalToUpdate = Read(oldID);

            if (pedalToUpdate != null)
            {
                pedalToUpdate.Name = pedal.Name;
                pedalToUpdate.Brand = pedal.Brand;
                pedalToUpdate.Effect = pedal.Effect;

                _db.SaveChanges();
            }
        }

        /// <summary>
        /// Implementing Delete Method
        /// </summary>
        /// <param name="ID"></param>
        public void Delete(int ID)
        {
            Pedals? pedalToDelete = Read(ID);

            if (pedalToDelete != null)
            {
                _db.Remove(pedalToDelete);
                _db.SaveChanges();
            }
        }


    }
}
