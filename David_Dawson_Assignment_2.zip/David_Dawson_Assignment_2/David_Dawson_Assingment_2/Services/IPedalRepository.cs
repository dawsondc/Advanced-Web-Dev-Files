﻿using David_Dawson_Assingment_2.Models.Entities;

namespace David_Dawson_Assingment_2.Services
{
    /// <summary>
    /// Interface for each method of CRUD
    /// </summary>
    public interface IPedalRepository
    {
        ICollection<Pedals> ReadAll();
        Pedals Create(Pedals pedal);
        Pedals Read(int ID);
        void Update(int oldID, Pedals pedal);
        void Delete(int ID);
    }
}
