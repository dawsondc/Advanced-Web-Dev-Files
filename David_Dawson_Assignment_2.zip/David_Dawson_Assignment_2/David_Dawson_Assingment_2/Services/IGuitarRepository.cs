﻿using David_Dawson_Assingment_2.Models.Entities;

namespace David_Dawson_Assingment_2.Services
{
    /// <summary>
    /// Interface for each method of CRUD
    /// </summary>
    public interface IGuitarRepository
    {
        ICollection<GuitarDetails> ReadAll();
        GuitarDetails Create(GuitarDetails guitar);
        GuitarDetails? Read(int ID);
        void Update(int oldID, GuitarDetails guitar);
        void Delete(int ID);
    }
}
