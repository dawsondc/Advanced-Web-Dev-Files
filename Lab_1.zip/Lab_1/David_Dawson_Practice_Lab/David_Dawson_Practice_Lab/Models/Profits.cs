﻿namespace David_Dawson_Practice_Lab.Models
{

    //enums for guitar brand profits
    public class BrandProfits
    {
        public string Guitar_Brands { get; set; }//property
        public string Guitar_Profits { get; set; }//property
    }
}
