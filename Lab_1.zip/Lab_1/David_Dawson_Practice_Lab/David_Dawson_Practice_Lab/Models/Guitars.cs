﻿namespace David_Dawson_Practice_Lab.Models
{
    public enum Guitars
    {
        Gibson,
        Ibanez,
        Dean,
        Jackson,
        Epiphone,
        PRS,
        Fender,
        Schecter
    }
}
