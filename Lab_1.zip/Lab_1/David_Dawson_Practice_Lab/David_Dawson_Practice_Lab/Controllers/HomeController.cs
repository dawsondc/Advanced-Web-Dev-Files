﻿using David_Dawson_Practice_Lab.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace David_Dawson_Practice_Lab.Controllers
{
    //***************************************************************************************************//
    public class HomeController : Controller
    {
        //Action method to output the simple types
        public IActionResult SimpleTypes()
        {
            //calling variables
            bool variable = true;
            sbyte value = -128;
            decimal dec = 1.34m;
            float water = 4.56f;
            uint big = 32768;
            short small = 32767;

            //creating a string using string interpolation
            string types = $"{variable} {value} {dec} {water} {big} {small}";//

            // returning the string to be displayed
            return Content(types);
        }

    //***************************************************************************************************//
        //Action method to output eNums
        public IActionResult GuitarBrands()
        {
            //ENum Variables
            Guitars Num1 = Guitars.Gibson;
            Guitars Num2 = Guitars.Ibanez;
            Guitars Num3 = Guitars.PRS;
            Guitars Num4 = Guitars.Schecter;
            Guitars Num5 = Guitars.Dean;
            Guitars Num6 = Guitars.Jackson;
            Guitars Num7 = Guitars.Fender;
            Guitars Num8 = Guitars.Epiphone;

            //creating a string using string interpolation to output the ENums
            String Brand1 = $"{Num1} is the #1 popoular guitar brand.\n";
            String Brand2 = $"{Num2} is the #2 popoular guitar brand.\n";
            String Brand3 = $"{Num3} is the #3 popoular guitar brand.\n";
            String Brand4 = $"{Num4} is the #4 popoular guitar brand.\n";
            String Brand5 = $"{Num5} is the #5 popoular guitar brand.\n";
            String Brand6 = $"{Num6} is the #6 popoular guitar brand.\n";
            String Brand7 = $"{Num7} is the #7 popoular guitar brand.\n";
            String Brand8 = $"{Num8} is the #8 popoular guitar brand.\n";

            //return the strings
            return Content(Brand1 + Brand2 + Brand3 + Brand4 + Brand5 + Brand6 + Brand7 + Brand8);
        }

    //***************************************************************************************************//
        
        /// <summary>
        /// Code for class types  //PUT ON ALL CODE BLOCKS!!!!!!!!!!!
        /// </summary>
        /// <returns></returns>
        public IActionResult ProfitMargin()
        {
            //array of the BrandProfit class
            BrandProfits[] array_profits = new BrandProfits[8];

            //Creating the arrays
            array_profits[0] = new BrandProfits { Guitar_Brands = "Gibson", Guitar_Profits = "$505 Million" };
            array_profits[1] = new BrandProfits { Guitar_Brands = "Ibanez", Guitar_Profits = "$80 Million" };
            array_profits[2] = new BrandProfits { Guitar_Brands = "Dean", Guitar_Profits = "$1 Million" };
            array_profits[3] = new BrandProfits { Guitar_Brands = "Jackson", Guitar_Profits = "$5 Million" };
            array_profits[4] = new BrandProfits { Guitar_Brands = "Epiphone", Guitar_Profits = "$29 Million" };
            array_profits[5] = new BrandProfits { Guitar_Brands = "PRS", Guitar_Profits = "$63 Million" };
            array_profits[6] = new BrandProfits { Guitar_Brands = "Fender", Guitar_Profits = "$454 Million" };
            array_profits[7] = new BrandProfits { Guitar_Brands = "Schecter", Guitar_Profits = "$9 Million" };

            //return as Json
            return Json(array_profits);
        }
        //***************************************************************************************************//


        //Code for array types
        public IActionResult PopularGuitars()
        {
            //Declaring Arrays of strings
            string[] gibson = new string[3] { "Les Paul", "SG", "E-335" };
            string[] ibanez = new string[3] { "JEM", "RG", "S Series" };
            string[] dean = new string[3] {"The Z", "The Cadillac", "The V"};
            string[] jackson = new string[3] { "Dinky", "Soloist", "Rhodes" };
            string[] epiphone = new string[3] { "Les Paul", "Dove", "Explorer" };
            string[] PRS = new string[3] { "SE Series", "Bolt-On", "S2 Series" };
            string[] fender = new string[3] { "Stratocaster", "Telecaster", "Jazzmaster" };
            string[] schecter = new string[3] { "Hellraiser", "Damien", "Blackjack" };

            //returning arrays
            return Content($"Gibson: {gibson[0]}, {gibson[1]}, {gibson[2]}\n" +
                           $"Ibanez: {ibanez[0]}, {ibanez[1]}, {ibanez[2]}\n" +
                           $"Dean: {dean[0]}, {dean[1]}, {dean[2]},\n" +
                           $"Jackson: {jackson[0]},{jackson[1]}, {jackson[2]}\n" +
                           $"Epiphone: {epiphone[0]}, {epiphone[1]}, {epiphone[2]}\n" +
                           $"PRS: {PRS[0]}, {PRS[1]}, {PRS[2]}, \n" +
                           $"Fender: {fender[0]}, {fender[1]}, {fender[2]}, \n" +
                           $"Schecter: {schecter[0]}, {schecter[1]}, {schecter[2]}");
        }

        //***************************************************************************************************//

        //anonymous types
        public IActionResult FoundingYear()
        {
            //Declaring anonymous variables
            var GibsonYear = new { company = "Gibson", year = 1902, location = "Kalamazoom MI" };
            var IbanezYear = new { company = "Ibanez", year = 1957, location = "Nagoya, Japan" };
            var PRSYear = new { company = "PRS", year = 1985, location = "Stevenville, MD" };

            //returning the variables in a string
            return Content($"{GibsonYear.company} started in {GibsonYear.year} in {GibsonYear.location}\n" +
                           $"{IbanezYear.company} started in {IbanezYear.year} in {IbanezYear.location}\n" +
                           $"{PRSYear.company} started {PRSYear.year} in {PRSYear.location}");
        }


        //***************************************************************************************************//

        //code for simple LINQ


        //***************************************************************************************************//

        //code for nullable tpyes


        //***************************************************************************************************//

        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}